
require(MASS)

tiling <- function(n,m,Tm=NULL,Tl=NULL,count=NULL,df=function(x) paste(x,collapse="_")) {
    ## Initial tiling
    ## Tiling matrix as in Alg. 1
    if(is.null(Tm)) Tm <- matrix(as.character(rep(1:m,each=n)),nrow=n,ncol=m)
    ## Additionally, we maintain a hash table of tiles (R,C).
    if(is.null(Tl)) {
        Tl <- new.env(hash=TRUE)
        for(j in 1:m) Tl[[as.character(j)]] <- list(R=1:n,C=j)
    }
    if(is.null(count)) count <- m

    ## Output unique id number
    newid <- function() {
        count <<- count+1
        as.character(count)
    }

    ## Tiling that freezes everything within tile.
    add0tile <- function(R=1:n,C=1:m) for(i in R) addtile(i,C)

    ## Add tile to a structure
    addtile <- function(R=1:n,C=1:m) {
        if(length(R)>0 && length(C)>0) {
            S <- new.env(hash=TRUE)
            ids <- NULL
            for(i in R) {
                raw <- Tm[i,C]
                K <- df(raw) # hash of permutation ids
                if(exists(K,envir=S)) {
                    ##if(any(raw!=S[[K]]$raw)) stop("addtile: hash collision.") # This is probably over-cautious, but can however catch some programming errors (e.g., NAs)
                    S[[K]]$rows <- c(S[[K]]$rows,i)
                } else {
                    id <- unique(raw)
                    ids <- union(ids,id)
                    S[[K]] <- list(rows=i,id=id,raw=raw)
                }
            }
            for(K in ls(S)) {
                Cp <- NULL
                for(id in S[[K]]$id) Cp <- union(Cp,Tl[[id]]$C)
                id <- newid()
                Tm[S[[K]]$rows,Cp] <<- id
                Tl[[id]] <- list(R=S[[K]]$rows,C=Cp)
            }
            for(id in ids) { # remove overlapping rows from existing tiles
                Rnew <- setdiff(Tl[[id]]$R,R)
                if(length(Rnew)>0)
                    Tl[[id]]$R <- Rnew
                else
                    rm(list=id,envir=Tl) # if there are no rows left remove empty tile
            }
        }
    }

    copy <- function() {
        newTl <- new.env(hash=TRUE)
        for(x in ls(Tl,all.names=TRUE)) assign(x,get(x,Tl),newTl)
        tiling(n,m,Tm=Tm,Tl=newTl,count=count)
    }

    permute <- function() {
        p <- matrix(1:(n*m),nrow=n,ncol=m)
        for(key in ls(Tl)) {
            R <- Tl[[key]]$R
            C <- Tl[[key]]$C
            if(length(R)>1) p[R,C] <- p[sample(R),C]
        }
        c(p)
    }

    permutedata_matrix <- function(x,p) {
        matrix(x[p],nrow=n,ncol=m,dimnames=dimnames(x))
    }

    permutedata_df <- function(x,p) {
        pp <- p-n*rep(0:(m-1),each=n)
        if(any(pp<1 | n<pp)) stop("permutedata_df: permutations are not within column.")
        as.data.frame(lapply(1:m,function(j) x[pp[((j-1)*n+1):(j*n)],j]),
                      row.names=rownames(x),col.names=colnames(x))
    }

    permutedata_list <- function(x,p) {
        pp <- p-n*rep(0:(m-1),each=n)
        if(any(pp<1 | n<pp)) stop("permutedata_list: permutations are not within column.")
        a <- lapply(1:m,function(j) x[[j]][pp[((j-1)*n+1):(j*n)]])
        names(a) <- names(x)
        a
    }

    permutedata <- function(x,p=permute(),nmin=n) {
        if(is.matrix(x)) {
            if(nmin>n) {
                k <- 1+(nmin-1)%/%dim(x)[1]
                y <- matrix(NA,k*dim(x)[1],dim(x)[2],dimnames=dimnames(x))
                for(i in 1:k) y[((i-1)*dim(x)[1]+1):(i*dim(x)[1]),] <- permutedata_matrix(x,p=permute())
                y
            } else {
                permutedata_matrix(x,p)
            }
        } else if(is.data.frame(x)) {
            permutedata_df(x,p)
        } else {
            permutedata_list(x,p)
        }
    }

    cov_local <- function(x) {
        if(!is.matrix(x)) stop("needs matrix")
        x <- scale(x,center=TRUE,scale=FALSE)
        r <- matrix(NA,m,m,dimnames=list(colnames(x),colnames(x)))
        x0 <- matrix(NA,n,m)
        for(i in 1:m) x0[,i] <- ave(x[,i],Tm[,i])
        for(i in 1:(m-1)) {
            for(j in (i+1):m) {
                a <- x[,i]
                b <- x[,j]
                idx <- which(Tm[,i]!=Tm[,j])
                if(length(idx)>0) {
                    a[idx] <- x0[idx,i]
                    b[idx] <- x0[idx,j]
                }
                r[i,j] <- r[j,i] <- mean(a*b)
            }
        }
        diag(r) <- apply(x,2,function(y) mean(y^2))
        r
    }

    cor_local <- function(x) {
        cov2cor(cov_local(x))
    }


    list(add0tile=add0tile,
         addtile=addtile,
         copy=copy,
         permute=permute,
         permutedata=permutedata,
         cov=cov_local,
         cor=cor_local,
         status=function() list(n=n,m=m,Tm=Tm,Tl=Tl,count=count))
}

#' Whitening operator
#'
#' @param x1 n1Xm matrix
#' @param x2 n2Xm matrix
#'
#' Matrix x1 is transformed so that any difference in unit spherical distribution
#' signifies difference in distributions of x1 and x2. The operation is defined a a linear
#' operator such that whitening(x,x) gives a n1Xm matrix whose covariance matrix is a
#' unit matrix. Use ZCA-cor as recommended by https://arxiv.org/abs/1512.00809
#'
#' @return n1Xm matrix, transformation of x1.
#'
#' @export
whitening <- function(x1,x2) {
    a <- svd(cor(x2))
    w <- (((1/apply(x2,2,sd)) %o% (1/sqrt(a$d)))*a$u) %*% t(a$u)
    list(y=x1 %*% w,w=w)
}

findproj <- function(rdata1,rdata2,f=function(s) s,k=2) {
    a <- whitening(rdata1,rdata2)
    s <- svd(cov(a$y))
    u <- s$u
    d <- s$d
    v <- sapply(d,f)
    p <- order(v,decreasing=TRUE)[1:k]
    v <- v[p]
    u <- u[,p,drop=FALSE]
    d <- d[p]
    ## Projection directions are not necessarily orthogonal rotations.
    ## Force orthogonality using gs orthonormalisation.
    list(w=gs(a$w %*% u),v=v)
}

findproj2 <- function(cov1,cov2,k=2) {
    a <- svd(cov2cor(cov2))
    W <- (((1/sqrt(diag(cov2))) %o% (1/sqrt(a$d)))*a$u) %*% t(a$u) # ZCA-cor
    a <- svd(t(W) %*% cov1 %*% W)
    p <- order(a$d,decreasing=TRUE)[1:k]
    list(w=gs(W %*% a$u[,p,drop=FALSE]),v=a$d[p])
}

#' Normalizes vector
#'
#' @param x Vector of real numbers
#' @return Normalized vector
#'
#' @export
norm2 <- function(x) {
    s <- d2(x)
    if(s>0) x/s else x
}

#' Gram-Schmidt orthonormalization process
#'
#' @param x Matrix of size nXm of rank m
#' @return Matrix where columns are orthogonal and spanned by columns of x
#'
#' @export
gs <- function(x,eps=.Machine$double.eps^0.5) {
    m <- dim(x)[2]
    for(i in 1:m) {
        x[,i] <- norm2(x[,i])
        if(i<m) for(j in (i+1):m) x[,j] <- x[,j]-x[,i]*sum(x[,i]*x[,j])
    }
    x
}


#' Computes L2 norm
#'
#' @param x Vector of real numbers
#' @return L2 norm
#'
#' @export
d2 <- function(x) sqrt(sum(x^2))

###############################################################################################
                                        # Plotting and printing functions follow
###############################################################################################

#' Makes a character string of a numeric vector
#'
#' @param x numeric vector
#' @return string representation of the vector
#'
#' @export
largestdim <- function(x,n=names(x),intercept=TRUE) {
    if(intercept) {
        x0 <- x[1]
        x <- x[-1]
    }
    x <- x[abs(x)>0]
    if(length(x)>0) {
        p <- order(abs(x),decreasing=TRUE)[1:min(5,length(x))]
        s <- paste(mapply(function(y,n) sprintf("%+.2f (%s)",y,n),x[p],n[p]),
                   collapse=" ")
    } else {
        s <- ""
    }
    if(intercept) sprintf("%+.2f %s",x0,s) else s
}

#' ppairs - make a pairplot
ppairs <- function(x,y,z=NULL,value=value_dens,
                   col=brewer.pal(3,"Set2"),pch=c(".",".","."),high=TRUE) {
    nx <- dim(x)[1]
    ny <- dim(y)[1]
    nz <- if(is.null(z)) 0 else dim(z)[1]
    n <- nx+ny+nz
    mat <- if(is.null(z)) rbind(x,y) else rbind(x,y,z)
    if(is.data.frame(mat)) {
        mat <- matrix(unlist(lapply(mat,as.numeric)),
                      nrow=n,ncol=dim(mat)[2],dimnames=dimnames(mat))
    }
    cols <- c(rep(col[1],nx),rep(col[2],ny),rep(col[3],nz))
    pchs <- c(rep(pch[1],nx),rep(pch[2],ny),rep(pch[3],nz))
    ix <- iy <- rep(FALSE,n)
    ix[1:nx] <- TRUE
    iy[(nx+1):(nx+ny)] <- TRUE
    ## randomize plotting order
    p <- sample.int(n)
    mat <- mat[p,]
    ix <- ix[p]
    iy <- iy[p]
    cols <- cols[p]
    pchs <- pchs[p]

    aux <- function(a,b) {
        value(matrix(c(a[ix],b[ix]),nx,2),
              matrix(c(a[iy],b[iy]),ny,2))
    }

    if(high) {
        highv <- -Inf
        for(i in 1:(dim(x)[2]-1)) {
            for(j in (i+1):dim(x)[2]) {
                highv <- max(highv,aux(mat[,i],mat[,j]))
            }
        }
    } else {
        highv <- Inf
    }

    panel.cor <- function(x,y,digits=3,prefix="",cex.cor,...) {
        usr <- par("usr"); on.exit(par(usr))
        par(usr=c(0,1,0,1))
        r <- aux(x,y)
        txt <- format(c(r,0.123456789),digits=digits)[1]
        txt <- paste0(prefix,txt)
        if(missing(cex.cor)) cex.cor <- 0.8/strwidth(txt)
        ##
        text(0.5,0.5,txt,cex=cex.cor,col=if(r>=highv) "red" else "black")
    }

    panel.points <- function(x,y,cex=3,...) {
        if(high) {
            if(aux(x,y)>=highv)
                lines(c(min(x),max(x),max(x),min(x),min(x)),
                      c(min(y),min(y),max(y),max(y),min(y)),col="red")
        }
        points(x,y,cex=cex,...)
    }

    panel.hist <- function(x,col=NA,...) {
        usr <- par("usr"); on.exit(par(usr))
        par(usr = c(usr[1:2],0,1.5))
        h <- hist(x,plot=FALSE)
        breaks <- h$breaks; nB <- length(breaks)
        y <- h$counts; y <- y/max(y)
        rect(breaks[-nB],0,breaks[-1],y,col="gray",...)
    }

    pairs(mat,col=cols,pch=pchs,bty="n",xaxt="n",yaxt="n",
          diag.panel=panel.hist,lower.panel=panel.cor,upper.panel=panel.points,
          oma=c(0,0,0,0))
}

#' Makes an ellipse of data
#'
#' @param data nXd data matrix
#' @param sigma the size of ellipse (default 0.95 confidence area)
#' @param ... graphics parameters
#' @returns As a side effect makes an 95% confidence ellipse based on data matrix.
#'
#' @export
plotellipse <- function(data,sigma=qnorm(0.975),...) {
    data <- as.matrix(data[,1:2,drop=FALSE])
    s <- svd(mycov(data))
    x <- seq(from=0,to=2*pi,length.out=100)
    lines((rep(1,length(x)) %o% colMeans(data))
          +sigma*sqrt(s$d[1])*(cos(x) %o% s$u[,1])
          +sigma*sqrt(s$d[2])*(sin(x) %o% s$u[,2]),...)
}


#' Makes a scatterplot of the data
#'
#' @param data nXd data matrix
#' @param rdata nXd matrix of random data (not used)
#' @param currentplot list that contains the current w matrix and name of the axis
#' @param grouped a subset of 1:n that contains the current selection
#' @returns As a side effect makes a pairplot to the directions specified by w.
#'
#' @export
plotdata <- function(data,rdata1=NULL,rdata2=NULL,w,grouped=NULL,s1="",s2="") {
    w <- w[,1:2,drop=FALSE] # Projection vectors
    xy <- data %*% w
    if(!is.null(rdata1)) {
        rxy1 <- rdata1 %*% w
    } else {
        rxy1 <- matrix(0,0,dim(data)[2])
    }
    if(!is.null(rdata2)) {
        rxy2 <- rdata2 %*% w
    } else {
        rxy2 <- matrix(0,0,dim(data)[2])
    }
    if(s1!="") s1 <- sprintf("%s ",s1)
    if(s2!="") s2 <- sprintf("%s ",s2)
    plot(rbind(xy,rxy1,rxy2),
         type="n",
         bty="n",
         cex.lab=0.5,
         xlab=sprintf("%s%s",s1,largestdim(w[,1],n=colnames(data),intercept=FALSE)),
         ylab=sprintf("%s%s",s2,largestdim(w[,2],n=colnames(data),intercept=FALSE)))
    idx <- 1:dim(xy)[1] %in% grouped

    for(i in 1:dim(xy)[1]) lines(rbind(rxy1[i,],xy[i,]),col=if(i %in% grouped) "pink" else "lightgray")
    points(rxy1,pch=1,col=ifelse(idx,"pink","lightpink"))
    points(rxy2,pch=1,col=ifelse(idx,"green","lightgreen"))
    points(xy,pch=20,col=ifelse(idx,"red","black"))
    if(length(grouped)>0) {
        plotellipse(xy[grouped,,drop=FALSE],col="darkred",lwd=3)
        plotellipse(rxy1[grouped,,drop=FALSE],col="deeppink",lty="dotted",lwd=2)
        plotellipse(rxy2[grouped,,drop=FALSE],col="darkgreen",lty="dotted",lwd=2)
    }
}


#' Makes a scatterplot of the data
#'
#' @param data nXd data matrix
#' @param rdata nXd matrix of random data (not used)
#' @param currentplot list that contains the current w matrix and name of the axis
#' @param grouped a subset of 1:n that contains the current selection
#' @returns As a side effect makes a pairplot to the directions specified by w.
#'
#' @export
plotdata2 <- function(data,rdata1=NULL,rdata2=NULL,w,grouped=NULL,s1="",s2="",ca = 0.8, labs = FALSE, showsamples = TRUE) {
    w <- w[,1:2,drop=FALSE] # Projection vectors
    xy <- data %*% w
    if(!is.null(rdata1)) {
        rxy1 <- rdata1 %*% w
    } else {
        rxy1 <- matrix(0,0,dim(data)[2])
    }
    if(!is.null(rdata2)) {
        rxy2 <- rdata2 %*% w
    } else {
        rxy2 <- matrix(0,0,dim(data)[2])
    }
    if(s1!="") s1 <- sprintf("%s ",s1)
    if(s2!="") s2 <- sprintf("%s ",s2)

    xlabel <- ylabel <- ""
    if (labs) {
        xlabel <- sprintf("%s%s",s1,largestdim(w[,1],n=colnames(data),intercept=FALSE))
        ylabel <- sprintf("%s%s",s2,largestdim(w[,2],n=colnames(data),intercept=FALSE))
    }

    plot(rbind(xy,rxy1,rxy2),
         type="n",
         bty="n",
         cex.lab = 0.6,
         cex.axis = ca,
         xlab = xlabel,
         ylab = ylabel
         )
    idx <- 1:dim(xy)[1] %in% grouped

    col_sel        <- rgb(255 / 255, 187 / 255, 0)
    col_sel_border <- rgb(255 / 255, 125 / 255, 0)

    col_blue       <- rgb(50 / 255, 35 / 255, 135 / 255)
    col_green      <- rgb(15 / 255, 120 / 255, 50 / 255)

    ## real data data
    points(xy, pch = 1, col = ifelse(idx, "black", "black"), cex = 1.5)

    ## selection
    points(xy[idx, ], pch=21, col = col_sel_border, bg = col_sel, cex = 1.5)

    if (showsamples) {
        ## H1
        points(rxy1, pch=0, col = ifelse(idx, col_green, col_green), cex = 0.7)

        ## H2
        points(rxy2, pch=2, col = ifelse(idx, col_blue, col_blue), cex = 0.7)
    }

}


#' Makes a scatterplot of the data
#'
#' @param data nXd data matrix
#' @param rdata nXd matrix of random data (not used)
#' @param currentplot list that contains the current w matrix and name of the axis
#' @param grouped a subset of 1:n that contains the current selection
#' @returns As a side effect makes a pairplot to the directions specified by w.
#'
#' @export
plotdatafocus <- function(data,rdata1=NULL,rdata2=NULL,w,grouped=NULL,s1="",s2="",ca = 0.8, labs = FALSE, cluster_ind = NULL, showsamples = TRUE) {
    w <- w[,1:2,drop=FALSE] # Projection vectors
    xy <- data %*% w
    if(!is.null(rdata1)) {
        rxy1 <- rdata1 %*% w
    } else {
        rxy1 <- matrix(0,0,dim(data)[2])
    }
    if(!is.null(rdata2)) {
        rxy2 <- rdata2 %*% w
    } else {
        rxy2 <- matrix(0,0,dim(data)[2])
    }
    if(s1!="") s1 <- sprintf("%s ",s1)
    if(s2!="") s2 <- sprintf("%s ",s2)

    xlabel <- ylabel <- ""
    if (labs) {
        xlabel <- sprintf("%s%s",s1,largestdim(w[,1],n=colnames(data),intercept=FALSE))
        ylabel <- sprintf("%s%s",s2,largestdim(w[,2],n=colnames(data),intercept=FALSE))
    }

    plot(rbind(xy,rxy1,rxy2),
         type="n",
         bty="n",
         cex.lab = 0.6,
         cex.axis = ca,
         xlab = xlabel,
         ylab = ylabel
         )

    idx <- 1:dim(xy)[1] %in% grouped

    col_sel        <- rgb(255 / 255, 187 / 255, 0)
    col_sel_border <- rgb(255 / 255, 125 / 255, 0)

    col_blue <- rgb(50 / 255, 35 / 255, 135 / 255)
    col_green <- rgb(15 / 255, 120 / 255, 50 / 255)

    ## real data
    points(xy[idx,], pch=1, col = "black", cex = 1.5)
    points(xy[!(idx), ], pch=3, col = "black", cex = 1.5)

    ## marked cluster
    if (! is.null(cluster_ind)) {
        points(xy[cluster_ind, ], pch=21, col = col_sel_border, bg = col_sel, cex = 1.5)
    }

    if (showsamples) {
        ## H1
        points(rxy1[idx, ], pch = 0, col = col_green, bg = col_green, cex = 0.7)
        points(rxy1[!(idx), ], pch = 3, col = col_green, cex = 0.7)

        ## H2
        points(rxy2[idx, ], pch = 2, col = col_blue, bg = col_blue, cex = 0.7)
        points(rxy2[!(idx), ], pch = 3, col = col_blue, cex = 0.7)
    }
}


## Plot a figure using plotdata2 and save the result to a pdf-file
plotandsave <- function(data, rdata1, rdata2, w, grouped, ca = 2.5, fname = NULL, showplot = TRUE, labs = FALSE, pfunc = plotdata2, ...) {
    if (showplot) {
        pfunc(data    = data,
              rdata1  = rdata1,
              rdata2  = rdata2,
              w       = w,
              grouped = grouped,
              ca = ca,
              labs = labs, ...)
    }

    if (! is.null(fname)) {
        pdf(file = fname, width = 6, height = 6)

        pfunc(data    = data,
              rdata1  = rdata1,
              rdata2  = rdata2,
              w       = w,
              grouped = grouped,
              ca = ca,
              labs = labs, ...)

        dev.off()
    }

}

plotpcpandsave <- function(data, ind, fname) {
    pcplot(data, grouped = ind)

    if (! is.null(fname)) {
        pdf(file = fname, width = 7, height = 5)
        pcplot(data, grouped = ind)
        dev.off()
    }
}

mycov <- function(x) {
    x <- x-(rep(1,dim(x)[1]) %o% colMeans(x))
    (t(x) %*% x)/dim(x)[1]
}

clustered <- function(data,grouped) {
    a0 <- apply(data,2,sd)
    a <- apply(data[grouped,],2,sd)/a0
    a[a0==0] <- Inf
    p <- order(a)
    list(p=p,a=a[p])
}

pcplot <- function(data,grouped=c(),selected=c(),fc=clustered) {
    n <- dim(data)[1]
    m <- dim(data)[2]
    notgrouped <- setdiff(1:n,grouped)
    notselected <- setdiff(1:m,selected)

    ## scale data to [0,1]
    r <- apply(data,2,range)
    nz <- which(r[1,]!=r[2,])
    data[,nz] <- (data[,nz]-(rep(1,n) %o% r[1,nz]))/(rep(1,n) %o% (r[2,nz]-r[1,nz]))
    data[,-nz] <- 0.5
    if(length(grouped)>1) {
        aux <- fc(data,grouped)
        a <- aux$a
        p <- aux$p
        data <- data[,p]
    } else {
        p <- 1:m
    }
    sel <- rep(FALSE,m)
    sel[selected] <- TRUE
    sel <- which(sel[p])


    op <- par()
    par(pin=c(par("pin")[1],4.1))
    plot(c(0,1.3),c(1,m),type="n",xaxt="n",yaxt="n",bty="n",xlab="",ylab="",mar=c(0,0,0,0))
    for(i in 1:m) {
        lines(c(0,1),c(i,i),col=if(i %in% sel) "blue" else "gray")
        text(1,i,
             labels=if(length(grouped)>1) sprintf("%s (%.2f)",colnames(data)[i],a[i]) else colnames(data)[i],
             cex=0.5,col=if(i %in% sel) "blue" else "black",pos=4)
    }
    for(i in notgrouped) lines(data[i,],1:m,col="black")
    for(i in grouped) lines(data[i,],1:m,col="red")
    par(op)
    p
}


## Function for getting the column set of a tile given the row indices in the data
get_column_indices <- function(data, ind, thr) {
    v_tmp <- clustered(data, ind)
    v_tmp <- names(v_tmp$a)[which(v_tmp$a < thr)]
    which( colnames(data) %in% v_tmp )
}


#' L1 norms between two empirical distributions
#' 
#' @param x vector of real numbers
#' @param y vector of real numbers
#' 
#' The function computes empirical L1 norm between distributions x and y
#' 
#' @return Empirical L1 norm between x and y.
#' 
#' @export
L1 <- function(x,y) {
  nx <- length(x)
  ny <- length(y)
  if(nx==0 || ny==0) stop("L1: zero length vector.")
  n <- nx+ny
  w <- c(x,y) # All observations
  wt <- c(rep(1/nx,nx),rep(-1/ny,ny)) # weight contributed by observations (sums to zero!)
  p <- order(w) # order observations
  w <- w[p]
  wt <- wt[p]
  sum(abs(cumsum(wt[-n])*(w[-1]-w[-n])))
}

#' Make measure function f
makef <- function(data1,data2,cind,cval) {
  subset1=which(data1[,cind] %in% cval)
  subset2=which(data2[,cind] %in% cval)
  function(z) {
    z <- norm2(z)
    -L1(data1[subset1,-cind] %*% z,data2[subset2,-cind] %*% z)
  }
}

# Find unit vector minimising f
findprojf1 <- function(data,f,iter=1,lambda=1) {
  v <- Inf
  w <- norm2(rnorm(dim(data)[2]))
  g <- function(x) {
    f(x)+lambda*(sum(x^2)-1)^2/2
  }
  for(i in 1:iter) {
    a <- optim(norm2(rnorm(dim(data)[2])),g,method="BFGS")
    if(a$value<v) {
      v <- a$value
      w <- a$par
    }
  }
  names(w) <- colnames(data)
  list(w=norm2(w),v=v)
}

# Find k unit vectors minimising f, after to first direction further directions 
# are required to be orthogonal to the previous dimensions
findprojf <- function(data,f,iter=10,lambda=1,lambda2=lambda,k=2) {
  w <- matrix(NA,dim(data)[2],k,dimnames=list(colnames(data),NULL))
  v <- rep(NA,k)
  for(i in 1:k) {
    if(i<2) {
      a <- findprojf1(data,f,iter,lambda)
      w[,1] <- a$w
      v[1] <- a$v
    } else {
      h <- function(x) gs(matrix(c(w[,1:(i-1)],x),dim(data)[2],i))[,i]
      g <- function(x) f(h(x))+lambda2*sum((x %*% w[,1:(i-1),drop=FALSE])^2)/2
      a <- findprojf1(data,g,iter,lambda)
      w[,i] <- h(a$w)
      v[i] <- f(w[,i])
    }
  }
  list(w=w,v=v)
}

