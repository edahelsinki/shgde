function [Tile_output,ML_output,wholeset_output]=Churn(Data,Exploration)

Mdl1= fitctree(Data,'Churn');
[order1,order2]=sort(predictorImportance(Mdl1));
model_ML=fitctree(Data(:,order1(1:k)),'Churn');

k=10

mis_classified1=ones(1,10);
mis_classified_visual=ones(1,10);
mis_classified_ML=ones(1,10);

FP1=ones(1,10);
FP_visual=ones(1,10);
FP_ML=ones(1,10);

counter=1;
for i=1:k

    total=1:size(A,1);
    if counter+floor(size(A,1)/k)<size(A,1)
    	index=counter:counter+floor(size(A,1)/k);
    else
    	index=counter:size(A,1);
    end

    train=B(index,:);	
    total(index)=[];
    test=B(total,:);

    Mdl1 = fitctree(train,'Churn');
    label = predict(Mdl1,test);
    mis_classified1(i)=1-(sum(strcmp(label,test.Churn))/size(label,1));
    FP1(i)=sum(strcmp(label,'Yes').*strcmp(test.Churn,'No'));

    E=Data(:,Exploration);
    train=E(index,:);
    test=E(total,:);
    Mdl5 = fitctree(train,'Churn');
    label5 = predict(Mdl5,test);
    mis_classified_visual(i)=1-(sum(strcmp(label5,test.Churn))/size(label5,1));
    FP_visual(i)=sum(strcmp(label5,'Yes').*strcmp(test.Churn,'No'));

    F=Data(:,ML);
    train=F(index,:);
    test=F(total,:);
    Mdl6 = fitctree(train,'Churn');
    label6 = predict(Mdl6,test);
    mis_classified_ML(i)=1-(sum(strcmp(label6,test.Churn))/size(label6,1));
    FP_ML(i)=sum(strcmp(label6,'Yes').*strcmp(test.Churn,'No'));

    counter=counter+floor(size(A,1)/k)+1;
end

Tile_output=[mean(mis_classified_visual) mean(FP_visual)];
ML_output=[mean(mis_classified_ML) mean(FP_ML)];
wholeset_output=[mean(mis_classified1) mean(FP1)];
