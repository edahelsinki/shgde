
set.seed(42)
source("tiling3.R")

data_orig <- readRDS("socio_economics_germany_full.rds")
data_real <- scale(as.matrix(data_orig[,14:45]), scale=TRUE, center=TRUE)
data_factors <- data_orig[,3:5]
data_modified_type <- matrix(c(data_real,
                               as.numeric(data_factors[,"Type"])), 
                             nrow=dim(data_real)[1],
                             ncol=dim(data_real)[2]+1,
                             dimnames=list(rownames(data_real),
                                           c(colnames(data_real),"Type")))

data_modified_region <- matrix(c(data_real,
                                 as.numeric(data_factors[,"Region"])), 
                               nrow=dim(data_real)[1],
                               ncol=dim(data_real)[2]+1,
                               dimnames=list(rownames(data_real),
                                             c(colnames(data_real),"Region")))


experiment_stability <- function(x,f,k=3,nvals,cval) {
  cind <- dim(x)[2]
  size_class <- sum(x[,cind]==cval)
  
  ## Generate a random tile with at least 2 columns
  randomtile <- function() {
    i <- sample.int(dim(f)[2],size=1) # Pick a random factor
    list(R=which(sample(levels(f[,i]),size=1)==f[,i]), # rows are from some factor
         C=sample.int(dim(x)[2],size=1+sample.int(dim(x)[2]-1,size=1))) # 2...m columns
  }
  
  ## Create empty tilings
  ttx1 <- tiling(dim(x)[1],dim(x)[2])
  
  ## Add k random background tiles, with rows matching factors
  for(i in 1:k) {
    a <- randomtile()
    ttx1$addtile(a$R,a$C)
  }
  
  ttx2 <- ttx1$copy()
  
  ## Create two hypothesis tilings
  ttx1$addtile()
  for(i in dim(x)[2]) ttx2$addtile(C=i)
  
  res <- matrix(NA,0,4,dimnames=list(NULL,c("nval","k", "l1","sd")))
  for (nval in nvals) {
    ## Create data samples
    val <- rep(NA, 10)
    for (i in 1:10) { 
      nmin <- nval*ceiling(dim(x)[1]/size_class)
      data_h1 <- ttx1$permutedata(x,nmin=nmin)
      data_h2 <- ttx2$permutedata(x,nmin=nmin)
      projx <- findprojf(x[,-cind],makef(data_h1,data_h2,cind,cval),k=1)
      wx <- projx$w
      val[i] <- L1(data_h1[which(data_h1[,cind]==cval),-cind] %*% wx,data_h2[which(data_h2[,cind]==cval),-cind] %*% wx)
    }
    res <- rbind(res,matrix(c(nval,k, mean(val),sd(val)),1,4))
  }
  res
}

res_stability <- matrix(NA,0,4,dimnames=list(NULL,c("nval","k","l1","sd")))
nvals = c(50,100,500,1000)

data <- data_modified_type
for(cl in unique(data[,"Type"])) {
  for (k in c(0,3)) {
    for(i in 1:25) { 
      a <- experiment_stability(data,data_factors[,-1],nvals=nvals,cval=cl,k=k) 
      print(a)
      # a is matrix now...
      res_stability<- rbind(res_stability,a) 
    }
  }
}

data <- data_modified_region
for(cl in unique(data[,"Region"])) {
  for (k in c(0,3)) {
    for(i in 1:25) { 
      a <- experiment_stability(data,data_factors[,-2],nvals=nvals,cval=cl,k=k) 
      print(a)
      # a is matrix now...
      res_stability<- rbind(res_stability,a) 
    }
  }
}

saveRDS(res_stability,file="res_stability.rds")

#res <- readRDS("res_stability.rds")
res <- res_stability
relsd <- res[,4]/res[,3]
res <- cbind(res,relsd)
res <- res[-c(541,542,543,544),] # For some reason 0 values...
res_medians <- merge(merge(aggregate(res[,3],by=list(nval=res[,1],k=res[,2]),mean),
                           aggregate(res[,4],by=list(nval=res[,1],k=res[,2]),mean),
                               by=c("nval","k")),                      
                     #merge(aggregate(res[,4],by=list(nval=res[,1],k=res[,2]),max),
                           aggregate(res[,5],by=list(nval=res[,1],k=res[,2]),mean), #by=c("nval","k")),
                     by=c("nval","k"))
colnames(res_medians) <- c("nval","k", "meanl1","meansd","mean sd/l1")
res_medians <- res_medians[order(res_medians[,1]),]

