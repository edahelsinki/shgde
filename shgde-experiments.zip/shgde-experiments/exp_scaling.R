
set.seed(42)
source("tiling3.R")

experiment_scaling <- function(x,f,k=3,nmin=1,m1=dim(x)[2]-1, cval) {
  cind <- dim(x)[2]
  
  ## Generate a random tile with at least 2 columns
  randomtile <- function() {
    #i <- sample.int(dim(f)[2],size=1) # Pick a random factor
    list(R=which(sample(levels(f),size=1)==f), # rows are from some factor
         C=sample.int(dim(x)[2],size=1+sample.int(dim(x)[2]-1,size=1))) # 2...m columns
  }
  
  ## Tiling etc. part
  time1 <- system.time({
    ## Create empty tilings
    ttx1 <- tiling(dim(x)[1],dim(x)[2])
    
    ## Add k random background tiles, with rows matching factors
    for(i in 1:k) {
      a <- randomtile()
      ttx1$addtile(a$R,a$C)
    }
    
    ttx2 <- ttx1$copy()
    
    ## Create two hypothesis tilings
    ttx1$addtile()
    for(i in dim(x)[2]) ttx2$addtile(C=i)
    
    ## Create data samples
    data_h1 <- ttx1$permutedata(x,nmin=nmin)
    data_h2 <- ttx2$permutedata(x,nmin=nmin)
    
  })
  
  ## Finding view part
  time2 <- system.time({
    projx <- findprojf(x[,-cind],makef(data_h1,data_h2,cind,cval),k=1)
  })
  
  ## Rest is related more to debugging
  wx <- projx$w 
  wz <- norm2(rnorm(dim(x)[2]-1))
  
  l1 <- L1(data_h1[which(data_h1[,cind]==cval),-cind] %*% wx,data_h2[which(data_h2[,cind]==cval),-cind] %*% wx)
  l3 <- L1(data_h1[which(data_h1[,cind]==cval),-cind] %*% wz,data_h2[which(data_h2[,cind]==cval),-cind] %*% wz)
  
  res <- c(l1,l3,time1["elapsed"],time2["elapsed"])
  names(res) <- c("l1","lrandom","time1","time2")
  res
}

gensyntdata <- function(n=1000,k=5,d=10,sd=0.5) {
  centroids <- matrix(rnorm(k*d,sd=1),nrow=k,ncol=d)
  classes <- sample.int(k,size=n,replace=TRUE)
  binclass <- rep('NA', n)
  for (i in 1:k) {
    binclass[classes==i] <- kmeans(centroids,2)$cluster[i]
  }
  cbind(centroids[classes,]+matrix(rnorm(n*d,sd=sd),nrow=n,ncol=d),
        factor(classes),factor(binclass))
}

res_scaling_artif <- matrix(NA,0,5,dimnames=list(NULL,c("nmin","m","l1","time1","time2")))

for(n in c(500,1000,2000,4000)) {
  for (m in c(16,32,64,128)) {
    for(i in 1:49) {
      data <- gensyntdata(n=n,k=10,d=m,sd=0.5)
      data_factors <- as.factor(data[,dim(data)[2]-1])
      data <- data[,-(dim(data)[2]-1)]
      
      a <- experiment_scaling(data,data_factors,cval=1, nmin=n, m1=m)
      print(a)
      res_scaling_artif <- rbind(res_scaling_artif,matrix(c(n,m, a[1],a["time1"],a["time2"]),1,5))
    }
  }
}

saveRDS(res_scaling_artif,file="res_scaling_artif.rds")

# res <- readRDS("res_scaling_artif.rds")
res <- res_scaling_artif
res_time_artif_median <- merge(aggregate(res[,4],by=list(nmin=res[,1],m=res[,2]),median),
                          aggregate(res[,5],by=list(nmin=res[,1],m=res[,2]),median),
                          by=c("nmin","m"))
res_time_artif_median <- res_time_artif_median[order(res_time_artif_median[,1]),]
for(i in 1:dim(res_time_artif_median)[1]) {
  cat(sprintf("$%d$ & $%d$ & $%.2f$ & $%.2f$ \\\\\n",
              res_time_artif_median[i,1],
              res_time_artif_median[i,2],
              res_time_artif_median[i,3],
              res_time_artif_median[i,4]))
}


